// Vercel Serverless Function: /api/verify-key
// Set Environment Variables di Vercel:
//   SKY_VERIFY_URL = endpoint verifikasi dari dashboard SkyKeySystem
//   SKY_API_KEY    = API key/secret dari dashboard SkyKeySystem
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ valid: false, message: 'Method not allowed' });
  }
  const key = ((req.body && req.body.key) || '').toString().trim();
  if (!key) return res.status(400).json({ valid: false, message: 'Key kosong.' });

  if (!process.env.SKY_VERIFY_URL || !process.env.SKY_API_KEY) {
    return res.status(500).json({ valid: false, message: 'Server belum dikonfigurasi (SKY_VERIFY_URL / SKY_API_KEY).' });
  }

  try {
    const r = await fetch(process.env.SKY_VERIFY_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + process.env.SKY_API_KEY
      },
      body: JSON.stringify({ key })
    });
    const d = await r.json().catch(() => ({}));
    const ok = r.ok && (d.valid === true || d.success === true);
    return res.status(200).json({ valid: ok, message: ok ? 'OK' : (d.message || 'Key tidak valid.') });
  } catch (e) {
    return res.status(502).json({ valid: false, message: 'Gagal menghubungi server verifikasi.' });
  }
}
